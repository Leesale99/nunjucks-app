# Contributing to Tiny-slider
:tada: Thanks for considing contribute to Tiny-slider.   
With the helps of contributors like you, Tiny-slider will work better, and our lives will easier and happier.   
#### Why this project?
Tiny-slider was strongly inspired by [Owl Carousel](https://owlcarousel2.github.io/OwlCarousel2/) which is a very powerful and awesome tool to make a slide show. But I don't want to include jQuery just for a slider (Do you?), that's why I started this project. Right now Tiny-slider is still young and may have some issues and lack some features. We can work together to make it much more useful for the whole community.   
#### Features needed:  
- [ ] custom build (build Tiny-slider based on your needs)
- [ ] modular

## How can I contribute?
#### Fire an issue
#### Request missing features
#### Submit a pull request