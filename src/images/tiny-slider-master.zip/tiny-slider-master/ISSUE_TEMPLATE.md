**Asking a question or submit a bug?**  
- [ ] Question
- [ ] Bug

**How can others repruduce the issue?**  
Link or Code example:

Tiny-slider version:   
OS:   
Browser:   
